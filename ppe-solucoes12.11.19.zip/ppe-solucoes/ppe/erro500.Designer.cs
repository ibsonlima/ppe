﻿namespace ppe
{
    partial class Erro500
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Erro500_btn = new System.Windows.Forms.Button();
            this.txt_h0_erro500 = new System.Windows.Forms.TextBox();
            this.portar_erro = new System.Windows.Forms.Button();
            this.fale_admin = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::ppe.Properties.Resources.erro500;
            this.pictureBox1.Location = new System.Drawing.Point(506, 222);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(311, 225);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // Erro500_btn
            // 
            this.Erro500_btn.BackColor = System.Drawing.SystemColors.HighlightText;
            this.Erro500_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Erro500_btn.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Erro500_btn.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.Erro500_btn.Location = new System.Drawing.Point(491, 577);
            this.Erro500_btn.Name = "Erro500_btn";
            this.Erro500_btn.Size = new System.Drawing.Size(340, 35);
            this.Erro500_btn.TabIndex = 20;
            this.Erro500_btn.Text = "VOLTAR PARA A HOME";
            this.Erro500_btn.UseVisualStyleBackColor = false;
            this.Erro500_btn.Click += new System.EventHandler(this.Erro500_btn_Click);
            // 
            // txt_h0_erro500
            // 
            this.txt_h0_erro500.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.txt_h0_erro500.Font = new System.Drawing.Font("Calibri", 17.75F, System.Drawing.FontStyle.Bold);
            this.txt_h0_erro500.Location = new System.Drawing.Point(512, 461);
            this.txt_h0_erro500.Name = "txt_h0_erro500";
            this.txt_h0_erro500.Size = new System.Drawing.Size(298, 29);
            this.txt_h0_erro500.TabIndex = 21;
            this.txt_h0_erro500.Text = "Erro 500 interno do Servidor!";
            // 
            // portar_erro
            // 
            this.portar_erro.BackColor = System.Drawing.SystemColors.HotTrack;
            this.portar_erro.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.portar_erro.FlatAppearance.BorderSize = 0;
            this.portar_erro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.portar_erro.Font = new System.Drawing.Font("Calibri", 11F);
            this.portar_erro.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.portar_erro.Location = new System.Drawing.Point(1123, 58);
            this.portar_erro.Margin = new System.Windows.Forms.Padding(4);
            this.portar_erro.Name = "portar_erro";
            this.portar_erro.Size = new System.Drawing.Size(141, 38);
            this.portar_erro.TabIndex = 24;
            this.portar_erro.Text = "REPORTAR ERRO";
            this.portar_erro.UseVisualStyleBackColor = false;
            this.portar_erro.Click += new System.EventHandler(this.portar_erro_Click);
            // 
            // fale_admin
            // 
            this.fale_admin.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fale_admin.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.fale_admin.FlatAppearance.BorderSize = 2;
            this.fale_admin.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fale_admin.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.fale_admin.Location = new System.Drawing.Point(931, 58);
            this.fale_admin.Margin = new System.Windows.Forms.Padding(4);
            this.fale_admin.Name = "fale_admin";
            this.fale_admin.Size = new System.Drawing.Size(184, 38);
            this.fale_admin.TabIndex = 23;
            this.fale_admin.Text = "Falar com administrador";
            this.fale_admin.UseVisualStyleBackColor = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.ErrorImage = null;
            this.pictureBox2.Image = global::ppe.Properties.Resources.logo_PPE;
            this.pictureBox2.InitialImage = null;
            this.pictureBox2.Location = new System.Drawing.Point(107, 58);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(253, 131);
            this.pictureBox2.TabIndex = 22;
            this.pictureBox2.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Font = new System.Drawing.Font("Calibri", 14.75F, System.Drawing.FontStyle.Bold);
            this.textBox1.Location = new System.Drawing.Point(394, 493);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(535, 25);
            this.textBox1.TabIndex = 25;
            this.textBox1.Text = "Opa! Houve um erro, por favor tente novamente mais tarde.";
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold);
            this.textBox2.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.textBox2.Location = new System.Drawing.Point(404, 530);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(514, 20);
            this.textBox2.TabIndex = 26;
            this.textBox2.Text = "O servidor encontrou um erro interno, e não pode concluir sua solicitção";
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Erro500
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HighlightText;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.portar_erro);
            this.Controls.Add(this.fale_admin);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.txt_h0_erro500);
            this.Controls.Add(this.Erro500_btn);
            this.Controls.Add(this.pictureBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Erro500";
            this.Text = "tetetetet";
            this.Load += new System.EventHandler(this.Erro500_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Erro500_btn;
        private System.Windows.Forms.TextBox txt_h0_erro500;
        private System.Windows.Forms.Button portar_erro;
        private System.Windows.Forms.Button fale_admin;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
    }
}