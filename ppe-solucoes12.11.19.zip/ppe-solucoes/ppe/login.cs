﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ppe
{
    public partial class home : Form
    {
        public home()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click_1(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_entrar_Click(object sender, EventArgs e)
        {
            /*
            string username = email_login.Text;
            string password = textBox1.Text;

            if (username == "didocokurt@gmail.com" && password == "123123")
            {*/
                this.Hide();
                var form1 = new dashboard_home();
                form1.Closed += (s, args) => this.Close();
                form1.Show();





          /*  }
            else if (!username.Contains("@"))
            {
                MessageBox.Show("Digite um e-mail válido", "Aviso");
                email_login.Focus();
            }
            else if (password.Length < 6)
            {
                MessageBox.Show("senha deve ser maior ou igual a 6 caracteres ", "Aviso");
                textBox1.Focus();
            }
            else
            {
                MessageBox.Show("Usuário ou senha incorreta", "Aviso");
                email_login.Focus();
            }*/


        }

        private void email_login_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void home_Load(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            var redefinir_senha = new Redefinir_senha();
            redefinir_senha.Closed += (s, args) => this.Close();
            redefinir_senha.Show();
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            var criar_conta = new criar_contat();
            criar_conta.Closed += (s, args) => this.Close();
            criar_conta.Show();
        }

        private void bemvindo_TextChanged(object sender, EventArgs e)
        {

        }

        private void label_email_Click(object sender, EventArgs e)
        {

        }

        private void label_senha_Click(object sender, EventArgs e)
        {

        }

        private void portar_erro_Click(object sender, EventArgs e)
        {
            this.Hide();
            var class_erro_500 = new Erro500();
            class_erro_500.Closed += (s, args) => this.Close();
            class_erro_500.Show();
        }
    }
}
