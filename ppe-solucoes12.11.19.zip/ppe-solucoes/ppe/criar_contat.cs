﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ppe
{
    public partial class criar_contat : Form
    {
        public criar_contat()
        {
            InitializeComponent();
        }

        private void criar_contat_Load(object sender, EventArgs e)
        {

        }

        private void criar_conta_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            var conta_btn_entrar = new dashboard_home();
            conta_btn_entrar.Closed += (s, args) => this.Close();
            conta_btn_entrar.Show();
        }

        private void portar_erro_Click(object sender, EventArgs e)
        {
            this.Hide();
            var class_erro_500 = new Erro500();
            class_erro_500.Closed += (s, args) => this.Close();
            class_erro_500.Show();
        }
    }
}
