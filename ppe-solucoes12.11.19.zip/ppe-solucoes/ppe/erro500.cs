﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ppe
{
    public partial class Erro500 : Form
    {
        public Erro500()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void entrarff_TextChanged(object sender, EventArgs e)
        {

        }

        private void portar_erro_Click(object sender, EventArgs e)
        {
            this.Hide();
            var class_erro_500 = new Erro500();
            class_erro_500.Closed += (s, args) => this.Close();
            class_erro_500.Show();
        }

        private void Erro500_Load(object sender, EventArgs e)
        {

        }

        private void Erro500_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            var voltar_home = new dashboard_home();
            voltar_home.Closed += (s, args) => this.Close();
            voltar_home.Show();
        }
    }
}
