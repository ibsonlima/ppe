﻿namespace ppe
{
    partial class criar_contat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(criar_contat));
            this.portar_erro = new System.Windows.Forms.Button();
            this.fale_admin = new System.Windows.Forms.Button();
            this.criar_conta_btn = new System.Windows.Forms.Button();
            this.criar_conta_senha = new System.Windows.Forms.TextBox();
            this.criar_conta_email = new System.Windows.Forms.TextBox();
            this.label_senha = new System.Windows.Forms.Label();
            this.label_email = new System.Windows.Forms.Label();
            this.bemvindo = new System.Windows.Forms.TextBox();
            this.entrarff = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // portar_erro
            // 
            this.portar_erro.BackColor = System.Drawing.SystemColors.HotTrack;
            this.portar_erro.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.portar_erro.FlatAppearance.BorderSize = 0;
            this.portar_erro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.portar_erro.Font = new System.Drawing.Font("Calibri", 11F);
            this.portar_erro.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.portar_erro.Location = new System.Drawing.Point(1050, 73);
            this.portar_erro.Margin = new System.Windows.Forms.Padding(4);
            this.portar_erro.Name = "portar_erro";
            this.portar_erro.Size = new System.Drawing.Size(141, 38);
            this.portar_erro.TabIndex = 6;
            this.portar_erro.Text = "REPORTAR ERRO";
            this.portar_erro.UseVisualStyleBackColor = false;
            this.portar_erro.Click += new System.EventHandler(this.portar_erro_Click);
            // 
            // fale_admin
            // 
            this.fale_admin.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.fale_admin.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.fale_admin.FlatAppearance.BorderSize = 2;
            this.fale_admin.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fale_admin.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.fale_admin.Location = new System.Drawing.Point(858, 73);
            this.fale_admin.Margin = new System.Windows.Forms.Padding(4);
            this.fale_admin.Name = "fale_admin";
            this.fale_admin.Size = new System.Drawing.Size(184, 38);
            this.fale_admin.TabIndex = 5;
            this.fale_admin.Text = "Falar com administrador";
            this.fale_admin.UseVisualStyleBackColor = false;
            // 
            // criar_conta_btn
            // 
            this.criar_conta_btn.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.criar_conta_btn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.criar_conta_btn.Font = new System.Drawing.Font("Calibri", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.criar_conta_btn.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.criar_conta_btn.Location = new System.Drawing.Point(857, 471);
            this.criar_conta_btn.Name = "criar_conta_btn";
            this.criar_conta_btn.Size = new System.Drawing.Size(340, 35);
            this.criar_conta_btn.TabIndex = 19;
            this.criar_conta_btn.Text = "ENTRAR";
            this.criar_conta_btn.UseVisualStyleBackColor = false;
            this.criar_conta_btn.Click += new System.EventHandler(this.criar_conta_btn_Click);
            // 
            // criar_conta_senha
            // 
            this.criar_conta_senha.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.criar_conta_senha.Location = new System.Drawing.Point(858, 414);
            this.criar_conta_senha.Multiline = true;
            this.criar_conta_senha.Name = "criar_conta_senha";
            this.criar_conta_senha.PasswordChar = '*';
            this.criar_conta_senha.Size = new System.Drawing.Size(340, 35);
            this.criar_conta_senha.TabIndex = 18;
            this.criar_conta_senha.Text = "Escreva sua Senha!";
            // 
            // criar_conta_email
            // 
            this.criar_conta_email.ForeColor = System.Drawing.SystemColors.ScrollBar;
            this.criar_conta_email.Location = new System.Drawing.Point(858, 345);
            this.criar_conta_email.Multiline = true;
            this.criar_conta_email.Name = "criar_conta_email";
            this.criar_conta_email.Size = new System.Drawing.Size(340, 35);
            this.criar_conta_email.TabIndex = 17;
            this.criar_conta_email.Text = "Escreva seu email!";
            // 
            // label_senha
            // 
            this.label_senha.AutoSize = true;
            this.label_senha.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_senha.Location = new System.Drawing.Point(854, 392);
            this.label_senha.Name = "label_senha";
            this.label_senha.Size = new System.Drawing.Size(52, 19);
            this.label_senha.TabIndex = 16;
            this.label_senha.Text = "Senha:";
            // 
            // label_email
            // 
            this.label_email.AutoSize = true;
            this.label_email.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label_email.Location = new System.Drawing.Point(854, 323);
            this.label_email.Name = "label_email";
            this.label_email.Size = new System.Drawing.Size(49, 19);
            this.label_email.TabIndex = 15;
            this.label_email.Text = "Email:";
            // 
            // bemvindo
            // 
            this.bemvindo.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.bemvindo.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bemvindo.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.bemvindo.Location = new System.Drawing.Point(858, 288);
            this.bemvindo.Name = "bemvindo";
            this.bemvindo.Size = new System.Drawing.Size(332, 20);
            this.bemvindo.TabIndex = 14;
            this.bemvindo.Text = "É gratuito para inscrição, e só leva 5 minutos.";
            // 
            // entrarff
            // 
            this.entrarff.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.entrarff.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.entrarff.Location = new System.Drawing.Point(858, 251);
            this.entrarff.Name = "entrarff";
            this.entrarff.Size = new System.Drawing.Size(198, 26);
            this.entrarff.TabIndex = 13;
            this.entrarff.Text = "Criar nova conta";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(109, 251);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(384, 335);
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.ErrorImage = null;
            this.pictureBox1.Image = global::ppe.Properties.Resources.logo_PPE;
            this.pictureBox1.InitialImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(109, 73);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(253, 131);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // criar_contat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.HighlightText;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.criar_conta_btn);
            this.Controls.Add(this.criar_conta_senha);
            this.Controls.Add(this.criar_conta_email);
            this.Controls.Add(this.label_senha);
            this.Controls.Add(this.label_email);
            this.Controls.Add(this.bemvindo);
            this.Controls.Add(this.entrarff);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.portar_erro);
            this.Controls.Add(this.fale_admin);
            this.Controls.Add(this.pictureBox1);
            this.Name = "criar_contat";
            this.Text = "Criar uma nova conta";
            this.Load += new System.EventHandler(this.criar_contat_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button portar_erro;
        private System.Windows.Forms.Button fale_admin;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button criar_conta_btn;
        private System.Windows.Forms.TextBox criar_conta_senha;
        private System.Windows.Forms.TextBox criar_conta_email;
        private System.Windows.Forms.Label label_senha;
        private System.Windows.Forms.Label label_email;
        private System.Windows.Forms.TextBox bemvindo;
        private System.Windows.Forms.TextBox entrarff;
    }
}