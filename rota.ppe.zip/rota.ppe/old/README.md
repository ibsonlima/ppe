﻿# node-express
Projeto criado para demonstrar como podemos criar uma API com uma estrutura legal em 10 passos ;) 

Link do post:
https://goo.gl/zMwY28 
