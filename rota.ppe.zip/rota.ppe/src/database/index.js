const mongoose = require('mongoose');
// mongoose.createConnection('mongodb://localhost/noderest', { useNewUrlParser: true, useUnifiedTopology: true });
mongoose.connect('mongodb://localhost/noderest', { useNewUrlParser: true, useUnifiedTopology: true });
mongoose.Promise = global.Promise;
module.exports = mongoose;