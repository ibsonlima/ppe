const routes = require('express').Router()
const AuthController = require('./controller/authController')

routes.post('/register', AuthController.register);

routes.get('/register', AuthController.list);
routes.get('/register/:id', AuthController.userList);

routes.delete('/register', AuthController.deletarAll);

// routes.delete('/register', AuthController.deletarAll);

routes.post('/materias', AuthController.materias);

routes.get('/materias', AuthController.materiaslists);
routes.get('/materias/:id', AuthController.materiaslist);

routes.delete('/materias', AuthController.materiasDeleteAll);
routes.delete('/materias/:id', AuthController.materiasRemovoOne);

routes.put('/materias/:id', AuthController.materiasAtualizar);

module.exports = routes;