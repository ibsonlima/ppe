const User = require("../models/user");
const Materia = require("../models/materias");

module.exports = {
    register: async (req, res) => {
        try {
            const user = await User.create(req.body);
            res.send({ user })
        } catch (err) {
            return res.status(400).send({ error: 'Aconteceu Algum erro! create' })
        }
    },

    list: async (req, res) => {
        try {
            const user = await User.find()
            res.json(user)
        } catch (err) {
            return res.status(400).send({ error: 'Aconteceu Algum erro! get' })
        }
    },

    deletarAll: async (req, res) => {
        try {
            let userid = req.body.id
            const user = await User.remove({ userid })
            res.json(user)
        } catch (err) {
            return res.status(400).send({ error: 'Aconteceu Algum erro! get' })
        }
    },

    userList: async (req, res) => {
        try {
            let userid = req.params.id
            const user = await User.findById(userid)
            res.json(user)
        } catch (err) {
            return res.status(400).send({ error: 'Aconteceu Algum erro! id get' })
        }
    },

    materias: async (req, res) => {
        try {
            const materia = await Materia.create(req.body);
            res.send({ materia })
        } catch (err) {
            return res.status(400).send({ error: 'Aconteceu Algum erro! Materia' })

        }
    },

    materiasAtualizar: async (req, res) => {
        try {

            const materia = await Materia.updateOne({ _id: req.params.id }, { '$set': req.body })
            res.json(materia)

            // const materia = await Materia.update(req.body);
            // res.send({ materia })
        } catch (err) {
            return res.status(400).send({ error: 'Aconteceu Algum erro! Materia Put' })

        }
    },

    materiaslists: async (req, res) => {
        try {
            const materia = await Materia.find(req.body);
            res.send({ materia })
        } catch (err) {
            return res.status(400).send({ error: 'Aconteceu Algum erro! create Materias' })
        }
    },

    materiaslist: async (req, res) => {
        try {
            let materiaid = req.params.id
            const materia = await Materia.findById(materiaid)
            res.json(materia)
        } catch (err) {
            return res.status(400).send({ error: 'Aconteceu Algum erro! create Materias id list' })
        }
    },

    materiasRemovoOne: async (req, res) => {
        try {
            let materiaid = req.params.id
            const materia = await Materia.findByIdAndRemove(materiaid)
            res.json(materia)
        } catch (err) {
            return res.status(400).send({ error: 'Aconteceu Algum erro! create Materias id list remove' })
        }
    },

    materiasDeleteAll: async (req, res) => {
        try {
            let materiaid = req.body.id
            const materia = await Materia.remove({ materiaid })
            res.json(materia)
        } catch (err) {
            return res.status(400).send({ error: 'Aconteceu Algum erro! get' })
        }
    }
}



