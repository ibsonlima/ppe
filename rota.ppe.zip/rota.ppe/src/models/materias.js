const mongoose = require('../database');
const MateriaShema = new mongoose.Schema({

    name: {
        type: String,
        require: true
    },

    assunto: {
        type: String,
        require: true
    },

    createdAt: {
        type: Date,
        default: Date.now
    },
});

const Materia = mongoose.model('Materia', MateriaShema);
module.exports = Materia;