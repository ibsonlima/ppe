const mongoose = require('../database');
const UserShema = new mongoose.Schema({
    name: {
        type: String,
        require: true
    },
    email: {
        type: String,
        unique: true,
        require: true,
        lowercase: true
    },
    password: {
        type: String,
        require: true
        //select: false // apaga a senha
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
}
    // { timestamps: true }

);

const User = mongoose.model('User', UserShema);
module.exports = User;